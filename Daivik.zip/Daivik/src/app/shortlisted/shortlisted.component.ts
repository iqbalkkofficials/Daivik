import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';
@Component({
  selector: 'app-shortlisted',
  templateUrl: './shortlisted.component.html',
  styleUrls: ['./shortlisted.component.css']
})
export class ShortlistedComponent implements OnInit {
  shortlisted:any
  constructor(private userservice:ServiceService) { }

  ngOnInit(): void {
    this.getshortlisted();
  }

  getshortlisted(){
    this.userservice.setshortlisteduser().subscribe((res) => {
      this.shortlisted=res;
      console.log(this.shortlisted);
    });
  }
}
