import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable, Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  
  url ='http://jsonplaceholder.typicode.com/';
  candidates = new Subject<any>();

  constructor(public http: HttpClient) {}

   // retreiving data for listing users in card
  getUsers() {
    return this.http.get(`${this.url}users`);
  }

  getShortlisteduser(id,name,email){
    this.candidates.next(id);
  }
  setshortlisteduser(){
    return this.candidates;
  }
  
}