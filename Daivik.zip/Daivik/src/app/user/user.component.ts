import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  userlist :any;
  shortlisted:boolean=false;
  userdetail:any;

  constructor(private userservice :ServiceService) { }

  ngOnInit(): void {
    this.getUser();
  }

  getUser(){
    this.userservice.getUsers().subscribe((res) => {
      this.userlist =res;
    });
  }

  shortlistuser(id,name,email){
    this.shortlisted=true;
    this.userservice.getShortlisteduser(id,name,email);
  }
  
  removeshortlistuser(){
    this.shortlisted=false;
   // this.userdetail=event;
  }
}
